package com.example.cst2335lab8;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.ui.AppBarConfiguration;

import com.example.cst2335lab8.databinding.ActivityBaseBinding;
import com.google.android.material.navigation.NavigationView;

public class BaseActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

  ActionBarDrawerToggle actionBarDrawerToggle;
  private AppBarConfiguration mAppBarConfiguration;
  private ActivityBaseBinding binding;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    binding = ActivityBaseBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());
    Toolbar toolbar = binding.appBarBase.toolbar;
    setSupportActionBar(toolbar);
    DrawerLayout drawer = binding.drawerLayout;

    actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open, R.string.close);
    drawer.addDrawerListener(actionBarDrawerToggle);
    actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
    actionBarDrawerToggle.syncState();
    binding.navView.setNavigationItemSelectedListener(this);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main_menu, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    switch (item.getItemId()) {
      case R.id.item_edit:
        Toast.makeText(this, "You clicked on item 1", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.item_delete:
        Toast.makeText(this, "You clicked on item 2", Toast.LENGTH_SHORT).show();
        return true;
      case R.id.item_add:
        Toast.makeText(this, "You clicked on item 3", Toast.LENGTH_SHORT).show();
        return true;
      default:
        return false;
    }
  }

  @Override
  public boolean onNavigationItemSelected(@NonNull MenuItem item) {
    binding.drawerLayout.closeDrawer(GravityCompat.START);
    switch (item.getItemId()) {
      case R.id.nav_home:
        if (this instanceof MainActivity) {
        } else {
          startActivity(new Intent(this, MainActivity.class));
        }
        return true;
      case R.id.nav_joke:
        if (this instanceof DadJokeActivity) {
        } else {
          startActivity(new Intent(this, DadJokeActivity.class));
        }
        return true;
      case R.id.nav_exit:
        finishAffinity();
        return true;
      default:
        return false;
    }
  }
}